# Frogfrogfrog

A game about catching flies.

[Play it!](https://pippinbarr.github.io/cart253-examples/topics/making/frogfrogfrog/index.html)

- [Ideas](./ideas.md)
- [Planning](./planning.md)
- [Pseudocode](./pseudocode.md)
