# Starting points

Finding metro tickets on the ground and trying to sell them

**Frog eating flies but it gets harder and harder to catch them**
